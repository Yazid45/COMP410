package SKPLIST_A4;

import gradingTools.comp410s20.assignment4.testcases.Assignment4Suite;


public class RunTests {
  public static void main(String[] args){ //runs Assignment 4 oracle tests
    Assignment4Suite.main(args);
  }
}

